#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pcap.h>
#include <time.h>
#include <net/if.h>
#include <netinet/in.h>
#include <net/ethernet.h>
#include <linux/if_ether.h>
#include <netpacket/packet.h>
#include <linux/if_link.h>
#include <netinet/ether.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <netinet/ip_icmp.h>

int num_ip = 0,ptr = 0;

typedef struct ip_address{
    char src_ip[30];
    char dst_ip[30];
    int count;
}ip_address;
ip_address table[100];

static void pcap_callback1(u_char *arg, const struct pcap_pkthdr *header, const u_char *content) {
    static int d = 0;
    printf("%3d: captured\n", ++d);
}//end pcap_callback1

static void pcap_callback2(u_char *arg, const struct pcap_pkthdr *header, const u_char *content) {
    static int d = 0;
    
    printf("No. %3d\n", ++d);

    //format timestamp
    struct tm *ltime;
    char timestr[16];
    time_t local_tv_sec;
    
    local_tv_sec = header->ts.tv_sec;
    ltime = localtime(&local_tv_sec);
    strftime(timestr, sizeof timestr, "%Y/%m/%d %H:%M:%S", ltime);
    
    //print packet in hex dump
    for(int i = 0 ; i < header->caplen ; i++) {
        printf("%02x ", content[i]);
    }//end for
    printf("\n\n");

    //break when captured 20 frames    
    if(d == 20) {
        pcap_t *handle = (pcap_t *)arg;
        pcap_breakloop(handle);
    }//end if
}//end pcap_callback2

static const char *mac_ntoa(u_int8_t *d) {
    static char mac[16][18];
    static int which = -1;

    which = (which + 1 == STR_BUF ? 0 : which + 1);

    memset(mac[which], 0, 18);
    snprintf(mac[which], sizeof(mac[which]), "%02x:%02x:%02x:%02x:%02x:%02x", d[0], d[1], d[2], d[3], d[4], d[5]);

    return mac[which];
}

static const char *ip_ntoa(void *i) 
{

    static char ip[16][INET_ADDRSTRLEN];
    static int which = -1;

    which = (which + 1 == STR_BUF ? 0 : which + 1);

    memset(ip[which], 0, INET_ADDRSTRLEN);
    inet_ntop(AF_INET, i, ip[which], sizeof(ip[which]));

    return ip[which];
}

static void ip_packet(struct ip *ip)
{
    u_char protocol=ip->ip_p;
    char src_ip[30]={0};
    char dst_ip[30]={0};

    //copy ip address
    snprintf(src_ip, sizeof(src_ip),"%s",ip_ntoa(&ip->ip_src));
    snprintf(dst_ip, sizeof(dst_ip),"%s",ip_ntoa(&ip->ip_dst));

    //統計每對(來源IP,目的IP)的封包數量
    int check=0;
    for(int i=0; i<100; i++)
    {
        if((strcmp(table[i].src_ip,src_ip)==0)&&(strcmp(table[i].dst_ip,dst_ip)==0))
        {
            table[i].count++;
            check=1;
            break;
        }
    }
    if(check!=1)
    {
        strcpy(table[ptr].src_ip,src_ip);
        strcpy(table[ptr].dst_ip,dst_ip);
        table[ptr].count++;
        ptr++;
    }
    //printf("%d\n",table[0].count);
    //print ip address
    printf("Source IP Address: %s\n",src_ip);
    printf("Destination IP Address: %s\n",dst_ip);

    char *p=(char *)ip+(ip->ip_hl<<2);
    if(protocol==IPPROTO_UDP)
    {   
        printf("Protocol: UDP\n");
        udp_packet((struct udphdr *)p);
    }
    if(protocol==IPPROTO_TCP)
    {
        printf("Protocol: TCP\n");
        tcp_packet((struct tcphdr *)p);
    }
}

static void dump_ethernet(u_int32_t length, const u_char *content)
{
    char src_mac[20]={0}; //source address
    char dst_mac[20]={0}; //destination address
    u_int64_t type;
    

    struct ether_header *ethernet=(struct ether_header *)content;
    type=ntohs(ethernet->ether_type);

    //copy header
    snprintf(src_mac, sizeof(src_mac), "%s",mac_ntoa(ethernet->ether_shost));
    snprintf(dst_mac, sizeof(dst_mac), "%s",mac_ntoa(ethernet->ether_dhost));

    //print MAC address
    printf("Source MAC Address: %s\n",src_mac);
    printf("Destination MAC Address: %s\n",dst_mac);
    
    if(type==ETHERTYPE_IP){
        ip_packet((struct ip *)(content+ETHER_HDR_LEN));
        num_ip++;
    }
}


int main(int argc,char **argv){
    char errbuf[PCAP_ERRBUF_SIZE];
    const char device[20];
    strcpy(device,argv[2]);

    pcap_t *handle = NULL;
    //open interface
    handle = pcap_open_live(device, 65535, 1, 1, errbuf);
    if(!handle) {
        fprintf(stderr, "pcap_open_live(): %s\n", errbuf);
        exit(1);
    }//end if
    
    struct pcap_pkthdr *header=NULL;
    const u_char *content=NULL;

    int total_amount = 0;
    int total_bytes = 0;
    memset(&table,0,sizeof(table));

    while(1){
	    //start capture pcap_dispatch()
	    int ret = pcap_dispatch(handle, -1, pcap_callback2, (u_char *)handle);
	    if(ret == -1) {
		fprintf(stderr, "pcap_dispatch(): %s\n", pcap_geterr(handle));
	    }
	    else if(ret == 0){
		printf("TIME OUT!\n");
	    }
	    else if(ret == 1){
        	
		total_amount++;
        	total_bytes += header->caplen;

	    	//format timestamp
	    	struct tm *ltime;
	    	char timestr[16];
	    	time_t local_tv_sec;
	    
	    	local_tv_sec = header->ts.tv_sec;
	    	ltime = localtime(&local_tv_sec);
	    	strftime(timestr, sizeof timestr, "%Y/%m/%d %H:%M:%S", ltime);

	    	//print header
	    	printf("Time: %s.%.6d\n", timestr, (int)header->ts.tv_usec);
		dump_ethernet(header->caplen, content);
	    }
	    else if(ret == -2){
		printf("No More Packet From %s\n",device);
		break;
	    }
    }

    for(int i = 0;i < ptr; i++){
	printf("[%s ~ %s]: %d\n",table[i].src_ip,table[i].dst_ip,table[i].count);
    }
    printf("Total IP Packet: %d\n",num_ip);
    printf("Read Packet: %d\n", total_amount);

    //free
    pcap_close(handle);
    
    return 0;
}





















